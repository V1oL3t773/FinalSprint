const MoreInfo = ({ item, onClose }) => {
    if (!item) return null;

    return (
        <div className="info-page" onClick={onClose}>
         <div className="info-box" onClick={e => e.stopPropagation()}>
          <button className="close-button" onClick={onClose}>X</button>
           <img src={item.img} alt={item.name} />
           <h2>{item.name}</h2>
           <p>{item.description}</p>
           <div className="price-cart">
            <span>Price {item.price}</span>
            <button className="cart-button">Add to Cart</button>
           </div>
         </div>
        </div>
    );
};

export default MoreInfo;