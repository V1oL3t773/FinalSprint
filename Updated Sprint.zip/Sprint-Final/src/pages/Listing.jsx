import { useEffect,useState } from "react";
import MoreInfo from "../components/MoreInfo";

const Listing = () => {
const [items, setItems] = useState([]);
const [selectedItem, setSelectedItem] = useState(null)

useEffect(() => {
  fetch("/db.json")
  .then((res) => res.json())
  .then((data) => setItems(data.furniture))
  .catch((error) => console.error(error));
}, []);

  return ( 
  <div>
   <div className="listing-mainbox">
     {items.map((item) => (
     <div className="item-box" key={item.id}>
      <img src={item.img} alt={item.name} />
      <p>
        {item.name} <br />
        {item.price}
      </p>
      <button className="details-button" onClick={() =>setSelectedItem(item)}>More Details</button>
     </div>
     ))}
   </div>

    {selectedItem && (
    <MoreInfo item={selectedItem} onClose={() => setSelectedItem(null)}/>
    )}
  </div>
  );
};

export default Listing;
