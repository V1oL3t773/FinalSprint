const Cart = () => {
  return ( 
  <div className="cart-background-box">
   <div className="cart-mainbox">
    <div className="cart-item-box">
      <h3>Cart</h3>
    </div>
     <div className="checkout-box">
      <h3>Cart Summary</h3>
      <p>Subtotal: <br />
        HST: <br />
        Total: 
      </p>
      <button className="checkout-button">Checkout</button>
     </div>
   </div>
  </div>
  );
};

export default Cart;