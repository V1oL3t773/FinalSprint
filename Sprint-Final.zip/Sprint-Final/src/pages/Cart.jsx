import { useContext } from "react";
import { CartContext } from "../context/CartContext";

const Cart = () => {
 const [items, setItems] = useContext(CartContext);

 const realItems = items.filter(item => item?.id && item?.price); 
 
 const subtotal = realItems.reduce((cst, item) => {
  const price = item.price ? parseFloat(item.price.replace("$", "")) : 0;
  return cst + price * (item.quantity || 1)}, 0)
 const hst = subtotal * 0.15;
 const total = subtotal + hst;

 const removeItem = (id) => {
  setItems(prevItems => prevItems.filter((item) => item.id !== id));
 };

 const updateQuantity = (id, value) => {
  const quan = parseInt(value, 10);
  if (isNaN(quan) || quan <= 0) {
    removeItem(id);
  } else {
    setItems(prevItems =>
    prevItems.map((item) =>
    item.id === id ? { ...item, quantity: quan } : item
    )
   );
  }
 };

 const checkoutalerts = () => {
  if (realItems.length === 0) {
    alert("Your cart is empty! Please addd items on the Listings page.");
    return;
  }
  alert("Your order has been placed!");
  setItems([]);
 }
 

  return ( 
  <div className="cart-background-box">
   <div className="cart-mainbox">
    <div className="cart-item-box">
      <h3>Cart</h3>
      {realItems.map((item) => (
        <div key={item.id} className="cart-item-row">
         <img src={item.img} alt={item.name} className="cart-img"/>
         <div className="item-details">
          <span className="item-name">{item.name}</span>
          <span className="item-price">{item.price}</span>
          <input type="number" min="1" value={item.quantity || 1} onChange={(e) => updateQuantity(item.id, e.target.value)}/>
         </div>
         <button className="remove-button" onClick={() => removeItem(item.id)}>Remove</button>
        </div>
      ))}
    </div>
     <div className="checkout-box">
      <h3>Cart Summary</h3>
      <p>
       Subtotal: ${subtotal.toFixed(2)}<br />
       HST: ${hst.toFixed(2)}<br />
       Total: ${total.toFixed(2)}
      </p>
      <button className="checkout-button" onClick={checkoutalerts}>Checkout</button>
     </div>
   </div>
  </div>
  );
};

export default Cart;