import { useState } from 'react'
import { CartProvider } from './context/CartContext'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './App.css'
import Home from "./pages/Home"
import Listing from "./pages/Listing"
import Cart from "./pages/Cart"
import  Header from "./components/Header"
import Footer from './components/Footer'

function App() {
  const [showAddTask, setShowAddTask] = useState(false);

  return (
   <CartProvider>
    <Router>
      <div className="page-box">
        <Header
        title="Fast Furniture"
        onAdd ={() => setShowAddTask(!showAddTask)}
        showAdd = {showAddTask}
        />
        <div className="content">
         <Routes>
          <Route path="/" element={<Home />} /> 
          <Route path="/listing" element={<Listing />} /> 
          <Route path="/cart" element={<Cart />} /> 
         </Routes>
        </div>
        <Footer/>
      </div>
    </Router>
   </CartProvider>
  )
}

export default App
