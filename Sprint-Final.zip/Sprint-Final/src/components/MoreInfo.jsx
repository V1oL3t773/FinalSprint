import { useContext } from "react";
import { CartContext } from "../context/CartContext";

const MoreInfo = ({ item, onClose }) => {
    if (!item) return null;
    const [items, setItems] = useContext(CartContext);

    const addItem = (nItem) => {
        if (!nItem.id || !nItem.name || !nItem.price || !nItem.img) return;
        setItems((prevItems) => {
            const exists = prevItems.find((cartItem) => cartItem.id === nItem.id);
            if (exists) {
                return prevItems.map((cartItem) =>
                cartItem.id === nItem.id
                 ? { ...cartItem, quantity: (cartItem.quantity || 1) + 1 }
                :cartItem);
                
            } else {
                return [...prevItems, { ...nItem, quantity: 1}];
            }
        })
    };

    return (
        <div className="info-page" onClick={onClose}>
         <div className="info-box" onClick={e => e.stopPropagation()}>
          <button className="close-button" onClick={onClose}>X</button>
           <img src={item.img} alt={item.name} />
           <h2>{item.name}</h2>
           <p>{item.description}</p>
           <div className="price-cart">
            <span>Price {item.price}</span>
            <button className="cart-button" onClick={() => addItem(item)}>Add to Cart</button>
           </div>
         </div>
        </div>
    );
};

export default MoreInfo;