import { useLocation, Link} from "react-router-dom";

const Header = ({ title,}) => {
    const location = useLocation();
    return (
        <header className="page-header">
            <div className="header-title">
             <h1>{title}</h1>
            </div>
             <nav className="header-nav">
              <ul>
                 <li><Link to="/">Home</Link></li>
                 <li><Link to="/Listing">Listings</Link></li>
                 <li><Link to="/Cart">Cart</Link></li>
              </ul>  
             </nav>
            
        </header>
    );
};
export default Header;