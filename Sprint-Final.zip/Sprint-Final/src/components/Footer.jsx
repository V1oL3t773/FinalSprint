const Footer = ({ title,}) => {

    return (
        <footer className="page-footer">
            <div className="footer-contact">
                <p>
                    Contact us: <br/>
                    Phone: 1(770) 784-9283 <br/>
                    Email: FastFurniture@email.com
                </p>
            </div>
            <div className="footer-copy">
                <p>
                    Copyright © 2025
                </p>
            </div>
            <div className="footer-links">
             <a href="https://facebook.com" target="_blank">Facebook</a>
             <a href="https://x.com" target="_blank">X</a>
             <a href="https://youtube.com" target="_blank">YouTube</a>
             <a href="https://instagram.com" target="_blank">Instagram</a>
            </div>
        </footer>
    );
};
export default Footer;